package simplenlg.lexicon.verbnet;

public enum VerbnetSlotType {

	VERB, NP, PREP, ADJ, ADV, LEX;

}
