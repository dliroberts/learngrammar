/**
 * This package contains classes for formatting texts into different markup languages
 * 
 * @author Ehud Reiter
 * 
 */
package simplenlg.formatter;